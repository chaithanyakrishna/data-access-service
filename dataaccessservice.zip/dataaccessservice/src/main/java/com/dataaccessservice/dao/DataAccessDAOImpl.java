package com.dataaccessservice.dao;

public class DataAccessDAOImpl implements DataAccessDAO {

	public Object get(String key) {
		// TODO make DB call to get value
		return "Sample Value";
	}

	public void put(String key, Object value) {
		// TODO make DB call to insert value

	}

}
