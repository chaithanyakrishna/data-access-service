package com.dataaccessservice.dao;

public interface DataAccessDAO {
	Object get(String key);

	void put(String key, Object value);
}
