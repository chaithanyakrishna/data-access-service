package com.dataaccessservice.cache;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;

public class FirstLevelCache implements Cache {
	@Value("${firstlevelcache.capacity}")
	private int capacity;

	private Map<String, CacheObject> cache;

	public FirstLevelCache() {
		cache = new HashMap<String, CacheObject>();
	}



	public Object get(String key) {

		CacheObject cacheObject = cache.get(key);
		cacheObject.setLastAccessedAt(new Date());

		return cacheObject.getValue();
	}

	public void put(String key, Object value) {
		
		CacheObject cacheObject = new CacheObject(key, value);
		if (cache.size() == capacity) {
			// TODO delete least accessed object.
		}
		cache.put(key, cacheObject);
	}

}
