package com.dataaccessservice.cache;

import java.util.Date;

public class CacheObject {
	private String key;
	private Object value;
	private Date lastAccessedAt;

	public CacheObject(String key, Object value) {
		this.key = key;
		this.value = value;
		this.lastAccessedAt = new Date();
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Date getLastAccessedAt() {
		return lastAccessedAt;
	}

	public void setLastAccessedAt(Date lastAccessedAt) {
		this.lastAccessedAt = lastAccessedAt;
	}

	@Override
	public boolean equals(Object o) {

		if (o == this)
			return true;
		if (!(o instanceof CacheObject)) {
			return false;
		}

		CacheObject cacheObject = (CacheObject) o;

		return cacheObject.key.equals(this.key);
	}


	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + key.hashCode();
		return result;
	}

}
