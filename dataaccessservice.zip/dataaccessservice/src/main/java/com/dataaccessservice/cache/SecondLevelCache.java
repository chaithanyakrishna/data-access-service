package com.dataaccessservice.cache;

public class SecondLevelCache implements Cache {

	public Object get(String key) {
		// TODO Get key, value details from file and update lastAccesssedTime

		return "";
	}

	public void put(String key, Object value) {
		// TODO Store key,value and lastAccessedTime to disk. This can be async work.
		// Instead of writing into one big file, we have to distribute the load to
		// multiple files to speedup file read and write operations. We can use output
		// of CacheObject.hashcode() as filename

		// TODO need a background thread to cleanup least accessed object. This thread
		// can be executed at regular intervals


	}




}
