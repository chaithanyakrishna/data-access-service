package com.dataaccessservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.dataaccessservice.cache.Cache;
import com.dataaccessservice.cache.FirstLevelCache;
import com.dataaccessservice.cache.SecondLevelCache;
import com.dataaccessservice.dao.DataAccessDAO;
import com.dataaccessservice.dao.DataAccessDAOImpl;
import com.dataaccessservice.service.Service;
import com.dataaccessservice.service.ServiceImpl;
import com.dataaccessservice.service.ServiceProxy;

@Configuration
@PropertySource("classpath:app.properties")
public class AppConfig {
	@Bean(name = "serviceImpl")
	public Service serviceImpl() {
		return new ServiceImpl();

	}

	@Bean
	@Primary
	public Service serviceProxy() {
		return new ServiceProxy();
	}

	@Bean(name = "firstLevelCache")
	public Cache firstLevelCache() {
		return new FirstLevelCache();
	}

	@Bean(name = "secondLevelCache")
	public Cache secondLevelCache() {
		return new SecondLevelCache();
	}

	@Bean
	public DataAccessDAO dataAccessDao() {
		return new DataAccessDAOImpl();
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();

	}

}
