package com.dataaccessservice.service;

import com.dataaccessservice.dao.DataAccessDAO;
import com.dataaccessservice.dao.DataAccessDAOImpl;

public class ServiceImpl implements Service {

	private DataAccessDAO dao;

	public ServiceImpl() {
		// TODO use Spring IOC to inject this
		dao = new DataAccessDAOImpl();
	}

	public Object get(String key) {

		return dao.get(key);
	}

	public void put(String key, Object value) {
		System.out.println("In impl");

		dao.put(key, value);
	}

}
