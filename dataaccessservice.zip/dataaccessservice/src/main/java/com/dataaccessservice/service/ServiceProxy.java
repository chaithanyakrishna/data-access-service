package com.dataaccessservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.dataaccessservice.cache.Cache;

public class ServiceProxy implements Service {

	@Autowired
	@Qualifier("firstLevelCache")
	private Cache firstLevelCache;

	@Autowired
	@Qualifier("secondLevelCache")
	private Cache secondLevelCache;

	@Autowired
	@Qualifier("serviceImpl")
	private Service serviceImpl;



	public Object get(String key) {

		Object value = firstLevelCache.get(key);
		if (value == null) {
			value = getFromSecondLevelCache(key);

		}

		if (value == null) {
			value = getFromServiceImpl(key);
		}
		return value;
	}

	private Object getFromSecondLevelCache(String key) {
		Object value=secondLevelCache.get(key);
		if(value!=null) {
			firstLevelCache.put(key, value);
		}
		return value;
	}

	private Object getFromServiceImpl(String key) {
		Object value = serviceImpl.get(key);
		if (value != null) {
			firstLevelCache.put(key, value);
			secondLevelCache.put(key, value);
		}
		return value;
	}

	public void put(String key, Object value) {

		serviceImpl.put(key, value);
		firstLevelCache.put(key, value);
		secondLevelCache.put(key, value);
	}

}
