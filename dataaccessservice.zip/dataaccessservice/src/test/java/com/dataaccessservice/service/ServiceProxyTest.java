package com.dataaccessservice.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dataaccessservice.cache.Cache;
import com.dataaccessservice.config.AppConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })
public class ServiceProxyTest {

	@Autowired
	private Service serviceImplProxy;

	@Autowired
	@Qualifier("serviceImpl")
	private Service serviceImpl;

	@Autowired
	@Qualifier("firstLevelCache")
	private Cache firstLevelCache;

	@Autowired
	@Qualifier("secondLevelCache")
	private Cache secondLevelCache;

	/**
	 * Make sure that when proxy is storing data in DB
	 * 
	 * */
	@Test
	public void testValuesInServiceImplAfterPut() {
		serviceImplProxy.put("1", "Sample Value");
		Object obj = serviceImpl.get("1");
		assertEquals("Sample Value", obj);
	}

	/**
	 * Make sure that when proxy is storing data in firstlevel cache
	 * 
	 */
	@Test
	public void testValuesInFirstLevelCacheAfterPut() {
		serviceImplProxy.put("1", "Sample Value");
		Object obj = firstLevelCache.get("1");
		assertEquals("Sample Value", obj);
	}

	/**
	 * Make sure that when proxy is storing data in secondlevel cache
	 * 
	 */
	@Test
	public void testValuesInSecondLevelCacheAfterPut() {
		serviceImplProxy.put("1", "Sample Value");
		Object obj = secondLevelCache.get("1");
		assertEquals("Sample Value", obj);
	}

}
