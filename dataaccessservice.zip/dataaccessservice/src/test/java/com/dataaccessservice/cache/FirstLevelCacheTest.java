package com.dataaccessservice.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dataaccessservice.config.AppConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { AppConfig.class })

public class FirstLevelCacheTest {
	@Autowired
	@Qualifier("firstLevelCache")
	private Cache firstLevelCache;

	@Test
	public void getTest() {
		firstLevelCache.put("1", "Sample Value");
		Object value = firstLevelCache.get("1");

		assertEquals("Sample Value", value);
	}

	@Test
	public void putTest() {
		firstLevelCache.put("1", "Sample Value");
		Object value = firstLevelCache.get("1");

		assertEquals("Sample Value", value);
	}

	/**
	 * Make sure that capacity is not exceeding
	 */
	@Test
	public void capacityTest() {
		assertTrue(true);
	}

}
