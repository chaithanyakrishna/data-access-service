package com.dataaccessservice.cache;

public class SecondLevelCacheTest {

}
