package com.dataaccessservice.dao;

public class DataAccessDAOImplTest {

}
